// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Thu Nov  6 05:54:27 2025
// Host        : DESKTOP-JFH9MT7 running 64-bit major release  (build 9200)
// Command     : write_verilog -mode funcsim -nolib -force -file
//               C:/Users/julas/G2B_Converter/G2B_Converter_TB/G2B_Converter_TB.sim/sim_1/impl/func/xsim/G2B_Converter_TB_func_impl.v
// Design      : g2b_converter
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a100tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* ECO_CHECKSUM = "c35e47cb" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module g2b_converter
   (i5GrayCode,
    o5Binary);
  input [4:0]i5GrayCode;
  output [4:0]o5Binary;

  wire [4:0]i5GrayCode;
  wire [3:0]i5GrayCode_IBUF;
  wire [4:0]o5Binary;
  wire [4:0]o5Binary_OBUF;

  IBUF \i5GrayCode_IBUF[0]_inst 
       (.I(i5GrayCode[0]),
        .O(i5GrayCode_IBUF[0]));
  IBUF \i5GrayCode_IBUF[1]_inst 
       (.I(i5GrayCode[1]),
        .O(i5GrayCode_IBUF[1]));
  IBUF \i5GrayCode_IBUF[2]_inst 
       (.I(i5GrayCode[2]),
        .O(i5GrayCode_IBUF[2]));
  IBUF \i5GrayCode_IBUF[3]_inst 
       (.I(i5GrayCode[3]),
        .O(i5GrayCode_IBUF[3]));
  IBUF \i5GrayCode_IBUF[4]_inst 
       (.I(i5GrayCode[4]),
        .O(o5Binary_OBUF[4]));
  OBUF \o5Binary_OBUF[0]_inst 
       (.I(o5Binary_OBUF[0]),
        .O(o5Binary[0]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'h96696996)) 
    \o5Binary_OBUF[0]_inst_i_1 
       (.I0(i5GrayCode_IBUF[0]),
        .I1(i5GrayCode_IBUF[2]),
        .I2(o5Binary_OBUF[4]),
        .I3(i5GrayCode_IBUF[3]),
        .I4(i5GrayCode_IBUF[1]),
        .O(o5Binary_OBUF[0]));
  OBUF \o5Binary_OBUF[1]_inst 
       (.I(o5Binary_OBUF[1]),
        .O(o5Binary[1]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h6996)) 
    \o5Binary_OBUF[1]_inst_i_1 
       (.I0(i5GrayCode_IBUF[1]),
        .I1(i5GrayCode_IBUF[3]),
        .I2(o5Binary_OBUF[4]),
        .I3(i5GrayCode_IBUF[2]),
        .O(o5Binary_OBUF[1]));
  OBUF \o5Binary_OBUF[2]_inst 
       (.I(o5Binary_OBUF[2]),
        .O(o5Binary[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT3 #(
    .INIT(8'h96)) 
    \o5Binary_OBUF[2]_inst_i_1 
       (.I0(i5GrayCode_IBUF[2]),
        .I1(o5Binary_OBUF[4]),
        .I2(i5GrayCode_IBUF[3]),
        .O(o5Binary_OBUF[2]));
  OBUF \o5Binary_OBUF[3]_inst 
       (.I(o5Binary_OBUF[3]),
        .O(o5Binary[3]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \o5Binary_OBUF[3]_inst_i_1 
       (.I0(i5GrayCode_IBUF[3]),
        .I1(o5Binary_OBUF[4]),
        .O(o5Binary_OBUF[3]));
  OBUF \o5Binary_OBUF[4]_inst 
       (.I(o5Binary_OBUF[4]),
        .O(o5Binary[4]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
