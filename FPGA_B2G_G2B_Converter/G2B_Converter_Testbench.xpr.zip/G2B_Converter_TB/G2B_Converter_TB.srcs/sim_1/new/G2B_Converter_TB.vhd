----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 11/04/2025 10:07:47 PM
-- Design Name: 
-- Module Name: G2B_Converter_TB - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;
use std.textio.all;
-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity G2B_Converter_TB is
--  Port ( );
end G2B_Converter_TB;

architecture Behavioral of G2B_Converter_TB is

-- DUT signals
    signal gray_s  : std_logic_vector(4 downto 0) := (others => '0');
    signal bin_dut : std_logic_vector(4 downto 0);
    signal exp_bin : std_logic_vector(4 downto 0);
    signal oracle_temp: std_logic_vector(4 downto 0); 
    signal clk_s      : std_logic := '0';

    -- Component declaration
    component g2b_converter
        port (
            i5GrayCode : in  std_logic_vector(4 downto 0);
            o5Binary   : out std_logic_vector(4 downto 0)
        );
    end component;

    -- File declarations
    file infile  : text open read_mode  is "C:\Users\julas\Downloads\G2B_Converter_TB\G2B_Converter.sim\sim_1\impl\func\xsim\input_gray.txt";
    file outfile : text open write_mode is "C:\Users\julas\Downloads\G2B_Converter_TB\G2B_Converter.sim\sim_1\impl\func\xsim\output_results.txt";

    -- Function: convert 5-bit Gray code to Binary
--    function gray_to_binary_5(g: std_logic_vector(4 downto 0)) return std_logic_vector is
--        variable b: std_logic_vector(4 downto 0);
--    begin
--        b(4) := g(4);
--        b(3) := b(4) xor g(3);
--        b(2) := b(3) xor g(2);
--        b(1) := b(2) xor g(1);
--        b(0) := b(1) xor g(0);
--        return b;
--    end function gray_to_binary_5;

    -- Function: convert std_logic_vector to string for logging
    function slv_to_string(slv: std_logic_vector) return string is
        variable result: string(1 to slv'length);
    begin
        for i in slv'range loop
            case slv(i) is
                when '0' => result(slv'length - i) := '0';
                when '1' => result(slv'length - i) := '1';
                when others => result(slv'length - i) := 'U';
            end case;
        end loop;
        return result;
    end function;

begin

    -- Virtual clock
    clk_process: process
    begin
        while true loop
            clk_s <= '0';
            wait for 5 ns;
            clk_s <= '1';
            wait for 5 ns;
        end loop;
    end process;

    -- Instantiate DUT
    UUT: g2b_converter
        port map(
            i5GrayCode => gray_s,
            o5Binary   => bin_dut
        );

    -- Test process
    process
        variable L          : line;
        variable input_str  : string(1 to 5);
        variable input_val  : std_logic_vector(4 downto 0);
        variable outline    : line;
        variable testnum    : integer := 0;
        variable dut_val    : std_logic_vector(4 downto 0);
        variable oracle_val : std_logic_vector(4 downto 0);
        variable gray_val : std_logic_vector(4 downto 0);
        variable oracle_var : std_logic_vector(4 downto 0);
--        variable oracle_temp: std_logic_vector(4 downto 0);
    begin

           -- Loop through all 32 Gray inputs
--        for i in 0 to 36 loop
        while not endfile(infile) loop
            readline(infile, L);
            read(L, input_str);
            
                -- Convert string to std_logic_vector
            for i in 1 to 5 loop
                if input_str(i) = '0' then
                    input_val(5-i) := '0';
                else
                    input_val(5-i) := '1';
                    wait for 1 ns;
                end if;
            end loop;

             -- Apply input to DUT
                gray_s <= input_val;
                wait for 10 ns;  -- allow DUT to respond

            
            -- Compute oracle using variables (immediate update)
                oracle_var(4) := gray_s(4);
                oracle_var(3) := oracle_var(4) xor gray_s(3);
                oracle_var(2) := oracle_var(3) xor gray_s(2);
                oracle_var(1) := oracle_var(2) xor gray_s(1);
                oracle_var(0) := oracle_var(1) xor gray_s(0);
                
           if testnum > 32 then
                oracle_var(4 downto 2) := (others => 'U');  -- force unknown bits
            end if;
        
            
            wait for 1 ns;
            
--             oracle_val := oracle_temp; 
                oracle_temp <= oracle_var;
                oracle_val := oracle_var;
             wait for 10 ns;
            -- Compute oracle and capture DUT
            dut_val := bin_dut;

            testnum := testnum + 1;

            if dut_val = oracle_val then
                write(outline, string'("Test "));
                write(outline, testnum);
                write(outline, string'(": GRAY="));
                write(outline, slv_to_string(gray_s));
                write(outline, string'(" DUT_BIN="));
                write(outline, slv_to_string(dut_val));
                write(outline, string'(" ORACLE_BIN="));
                write(outline, slv_to_string(oracle_val));
                write(outline, string'(" Result=PASS"));
                writeline(outfile, outline);
            else
                write(outline, string'("Test "));
                write(outline, testnum);
                write(outline, string'(" MISMATCH! GRAY="));
                write(outline, slv_to_string(gray_s));
                write(outline, string'(" DUT="));
                write(outline, slv_to_string(dut_val));
                write(outline, string'(" ORACLE="));
                write(outline, slv_to_string(oracle_val));
                writeline(outfile, outline);
                report "Mismatch detected at Test " & integer'image(testnum) severity error;
            end if;
        end loop;

        report "Simulation complete. Results written to output_g2b_results.txt" severity note;
        file_close(outfile);
        wait;
    end process;

    -----------------------------------------------------------------
    -- Process 2: Update exp_bin for waveform (concurrent)
    -----------------------------------------------------------------
    process(oracle_temp)
    begin
        exp_bin <= oracle_temp;
    end process;
    
end Behavioral;
