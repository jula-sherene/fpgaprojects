----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/21/2025 03:40:57 PM
-- Design Name: 
-- Module Name: g2b_converter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity g2b_converter is
    Port ( i5GrayCode : in STD_LOGIC_VECTOR (4 downto 0);
           o5Binary : out STD_LOGIC_VECTOR (4 downto 0));
end g2b_converter;

architecture Behavioral of g2b_converter is

    signal temp_b : std_logic_vector(4 downto 0); -- Temporary signals 

begin

-- Gray to Binary conversion (ripple logic)
    temp_b(4) <= i5GrayCode(4);                 -- MSB
    temp_b(3) <= temp_b(4) XOR i5GrayCode(3);
    temp_b(2) <= temp_b(3) XOR i5GrayCode(2);
    temp_b(1) <= temp_b(2) XOR i5GrayCode(1);
    temp_b(0) <= temp_b(1) XOR i5GrayCode(0);  -- LSB

    -- Assign temporary signals to output
    o5Binary <= temp_b;


end Behavioral;
