----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/17/2025 11:19:46 AM
-- Design Name: 
-- Module Name: b2g_converter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity b2g_converter is
    Port ( i5Binary : in STD_LOGIC_VECTOR (4 downto 0);
           o5GrayCode : out STD_LOGIC_VECTOR (4 downto 0));
end b2g_converter;

architecture Behavioral of b2g_converter is

begin
    o5GrayCode(4) <= i5Binary(4);
    o5GrayCode(3) <= i5Binary(4) XOR i5Binary(3);
    o5GrayCode(2) <= i5Binary(3) XOR i5Binary(2);
    o5GrayCode(1) <= i5Binary(2) XOR i5Binary(1);
    o5GrayCode(0) <= i5Binary(1) XOR i5Binary(0);
end Behavioral;
